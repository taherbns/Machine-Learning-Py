from flask import Flask, request, json
import pickle
import pandas as pd
import numpy as np
# App flask = express
app = Flask(__name__)

# Load ML model 
model = pickle.load(open('final_model.pickle', 'rb'))


# Define routes
@app.route('/prediction', methods=['POST'])
def get_ressource():
    # Get client request
    data = request.get_json(force=True)
    # Get value of key name client_message from the client
    preg = data['preg']
    plas = data['plas']
    pres = data['pres']
    skin = data['skin']
    test = data['test']
    mass = data['mass']
    pedi = data['pedi']
    age = data['age']
    user_data = [preg, plas, pres, skin, test, mass, pedi, age]
    user_data = np.array([user_data]).astype('float')
    print(user_data)
    prediction = model.predict(user_data)
    # st.write(prediction)
    prediction = int(prediction)
    # st.write(prediction)
    # Get probability
    # probability = model.predict_proba(user_data)[0]
    probability = model.predict_proba(user_data)
    probability = probability[0]

    # st.write(probability)
    probability = probability[prediction].round(2)
    print(f'Client sent: {[preg, plas, pres, skin, test, mass, pedi, age]}')
    outcome = {"class":prediction, "proba":probability}
    #response  = json.dumps(outcome)
    # return f'You requested: {preg, plas, pres, skin, test, mass, pedi, age}, Class: {prediction} - Proba: {probability}'
    return json.dumps(outcome)
# @app.post('/model')
# def get_ressource():
#     return 'OK'

if __name__ == '__main__':
    app.run(port=8007, debug=True)