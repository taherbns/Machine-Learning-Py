import streamlit as st
import pandas as pd
from flask.json import jsonify
# import pickle
url = 'http://127.0.0.1:8007/prediction' # Endpoint
import json, requests


def main():
    st.write(
        '''
        # Simple Diabetes Prediction App
        This App predicts diabetets cases (:red[Positive] :disappointed: or :green[Negative] :smile:)
        '''
    )
    # Import Model
    # model = pickle.load(open('final_model.pickle', 'rb'))
    st.sidebar.header('User Input Parameters')
    
    def user_input_features():
        preg = st.sidebar.slider('Preg', 0.0, 17.0, 3.8)
        plas = st.sidebar.slider('Plas', 0.0, 199.0, 120.0)
        pres = st.sidebar.slider('Pres', 0.0, 122.0, 70.0)
        skin = st.sidebar.slider('Skin', 0.0, 99.0, 20.0)
        test = st.sidebar.slider('Test', 0.0, 846.0, 100.0)
        mass = st.sidebar.slider('Mass', 0.0, 67.0, 31.0)
        pedi = st.sidebar.slider('Pedi', 0.1, 2.5, 0.4)
        age = st.sidebar.slider('Age', 21, 81, 33)
        data = {
            'preg': preg,
            'plas': plas,
            'pres': pres,
            'skin': skin,
            'test': test,
            'mass': mass,
            'pedi': pedi,
            'age': age
        }
        # dataframe = pd.DataFrame(data, index=[0])
        return data
    user_input = user_input_features() 
    data = json.dumps(user_input)
    response = requests.post(url, data)
    print(f'Response from server: {response.text}')
    st.subheader('User Input Parameters')
    
    dataframe = pd.DataFrame(user_input, index=[0])
    st.write(dataframe)
    st.subheader('Diagnostic Result')
    # st.write(response.json())
    server_response = response.json()
    
    # Get prediction
    predicted_class = server_response['class']
    probability = server_response['proba']
    # st.write(predicted_class, probability)
    if predicted_class == 1:
        st.write(f'<strong>Outcome</strong> : :red[Positive with probability of] {probability} % :disappointed:', unsafe_allow_html=True)
    else:
        st.write(f'<strong>Outcome</strong> : :green[Negative with probability of] {probability} % :smile:', unsafe_allow_html=True)
    

    
    
    
if __name__ == '__main__':
    main()






